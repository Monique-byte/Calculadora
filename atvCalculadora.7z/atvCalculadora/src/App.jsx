import React, { useState } from 'react';
import './App.css'; // Importando o arquivo de CSS

function App() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [result, setResult] = useState(null);

  const handleCalculation = (operator) => {
    const n1 = parseFloat(num1);
    const n2 = parseFloat(num2);
    let res;

    if (isNaN(n1) || isNaN(n2)) {
      setResult('Querido(a) Por favor insira números válidos');
      return;
    }

    switch (operator) {
      case '+':
        res = n1 + n2;
        break;
      case '-':
        res = n1 - n2;
        break;
      case '*':
        res = n1 * n2;
        break;
      case '/':
        res = n2 !== 0 ? n1 / n2 : 'Divisão por zero não pode -_-';
        break;
      default:
        res = 'Operação inválida';
    }

    setResult(res);
  };

  return (
    <div className="calculator-container">
      <h1>Calculadora</h1>
      <div className="input-container">
        <input
          type="number"
          value={num1}
          onChange={(e) => setNum1(e.target.value)}
          placeholder="Digite o primeiro número"
        />
      </div>
      <div className="input-container">
        <input
          type="number"
          value={num2}
          onChange={(e) => setNum2(e.target.value)}
          placeholder="Digite o segundo número"
        />
      </div>
      <div className="buttons-container">
        <button onClick={() => handleCalculation('+')}>+</button>
        <button onClick={() => handleCalculation('-')}>-</button>
        <button onClick={() => handleCalculation('*')}>*</button>
        <button onClick={() => handleCalculation('/')}>/</button>
      </div>
      <div className="result-container">
        <h2>Resultado: {result}</h2>
      </div>
    </div>
  );
}

export default App;
